var board = [[0, 0, 0],[0, 0, 0],[0, 0, 0],];
var HUMAN = -1;
var COMPUTER = +1;

/* The below function is for heuristic evaluation of state */
/* ------------------------------------------------------- */
function evaluation(state) 
{
	var score = 0;
	if (gameover(state, HUMAN)) 
	{
		score = -1;
	}
	else if (gameover(state,COMPUTER)) 
	{
		score = +1;
	} 
	else 
	{
		score = 0;
	}
	return score;
}

/* The below function tests whether a specific player wins or not */
/* -------------------------------------------------------------- */
function gameover(state, player) {
        var win_states = [[state[0][0], state[0][1], state[0][2]],[state[1][0], state[1][1], state[1][2]],[state[2][0], state[2][1], state[2][2]],[state[0][0], state[1][0], state[2][0]],[state[0][1], state[1][1], state[2][1]],[state[0][2], state[1][2], state[2][2]],[state[0][0], state[1][1], state[2][2]],[state[2][0], state[1][1], state[0][2]],];
	for (var i=0;i<8;i++) 
	{
		var line = win_states[i];
                var filled = 0;
                for (var j=0;j<3;j++) 
		{
                        if (line[j] == player)
                                filled=filled+1;
                }
                if (filled == 3)
                        return true;
        }
        return false;
}

/* The below function tests whether the human or computer wins */
/* ----------------------------------------------------------- */
function gameoverall(state) 
{
        return gameover(state, HUMAN) || gameover(state, COMPUTER);
}

/* The below function is for finding out the empty cells */
/* ----------------------------------------------------- */
function emptycells(state) 
{
        var cells = [];
        for(var x=0;x<3;x++) 
	{
                for(var y=0;y<3;y++) 
		{
                        if(state[x][y] == 0)
                                cells.push([x, y]);
                }
        }
	return cells;
}

/* A move is valid if the chosen cell is empty */
/* ------------------------------------------- */
function validmove(x,y) 
{
        var empty_cells = emptycells(board);
        try 
	{
                if(board[x][y] == 0) 
		{
                        return true;
                }
                else 
		{
                        return false;
                }
        }
	catch (e) 
	{
                return false;
        }
}

/* The below function is for setting the move on board, if the coordinates are valid */
/* ------------------------------------------------------- */
function setmove(x,y,player) 
{
        if (validmove(x,y)) 
	{
                board[x][y] = player;
                return true;
        }
        else 
	{
                return false;
        }
}

/* The below function is the AI function that choice the best move */
/* ------------------------------------- */
function minimax(state, depth, player) 
{
        var best;
        if (player == COMPUTER) 
	{
                best = [-1, -1, -1000];
        }
        else 
	{
                best = [-1, -1, +1000];
        }
        if (depth == 0 || gameoverall(state)) 
	{
                var score = evaluation(state);
                return [-1, -1, score];
        }

        emptycells(state).forEach(function (cell) 
	{
                var x = cell[0];
                var y = cell[1];
                state[x][y] = player;
                var score = minimax(state, depth-1, -player);
                state[x][y] = 0;
                score[0] = x;
                score[1] = y;
                if (player == COMPUTER) 
		{
                        if (score[2] > best[2])
                                best = score;
                }
                else 
		{
                        if (score[2] < best[2])
                                best = score;
                }
        });
        return best;
}

/* The below function calls the minimax function */
/* --------------------------------------------- */
function AITurn() 
{
        var x,y;
        var move;
        var cell;
        if (emptycells(board).length == 9) 
	{
                x = parseInt(Math.random() * 3);
                y = parseInt(Math.random() * 3);
        }
        else 
	{
                move = minimax(board, emptycells(board).length, COMPUTER);
                x = move[0];
                y = move[1];
        }
        if (setmove(x, y, COMPUTER)) 
	{
                cell = document.getElementById(String(x) + String(y));
                cell.innerHTML = "O";
        }
}

/* The below function is the main function */
function cellclicked(cell) 
{
        var button = document.getElementById("restart_button");
        button.disabled = true;
        var conditionToContinue = gameoverall(board) == false && emptycells(board).length > 0;
        if (conditionToContinue == true) 
	{
                var x = cell.id.split("")[0];
                var y = cell.id.split("")[1];
                var move = setmove(x, y, HUMAN);
                if (move == true) 
		{
                        cell.innerHTML = "X";
                        if (conditionToContinue)
                                AITurn();
                }
        }
	if(gameover(board,COMPUTER)) 
	{
               	var lines;
                var cell;
                var msg;
                if (board[0][0] == 1 && board[0][1] == 1 && board[0][2] == 1)
                        lines = [[0, 0], [0, 1], [0, 2]];
                else if (board[1][0] == 1 && board[1][1] == 1 && board[1][2] == 1)
                        lines = [[1, 0], [1, 1], [1, 2]];
                else if (board[2][0] == 1 && board[2][1] == 1 && board[2][2] == 1)
                        lines = [[2, 0], [2, 1], [2, 2]];
                else if (board[0][0] == 1 && board[1][0] == 1 && board[2][0] == 1)
                        lines = [[0, 0], [1, 0], [2, 0]];
                else if (board[0][1] == 1 && board[1][1] == 1 && board[2][1] == 1)
                        lines = [[0, 1], [1, 1], [2, 1]];
                else if (board[0][2] == 1 && board[1][2] == 1 && board[2][2] == 1)
                        lines = [[0, 2], [1, 2], [2, 2]];
                else if (board[0][0] == 1 && board[1][1] == 1 && board[2][2] == 1)
                        lines = [[0, 0], [1, 1], [2, 2]];
                else if (board[2][0] == 1 && board[1][1] == 1 && board[0][2] == 1)
                        lines = [[2, 0], [1, 1], [0, 2]];

                for (var i=0;i<lines.length;i++) 
		{
                        cell = document.getElementById(String(lines[i][0]) + String(lines[i][1]));
                        cell.style.color = "#FF4500";
                }
		msg = document.getElementById("result");
		msg.style.color = "#CD5C5C"
                msg.innerHTML = "YOU LOSE!";

        }
        if (emptycells(board).length == 0 && !gameoverall(board)) 
	{
                var msg = document.getElementById("result");
		msg.style.color= "#008000"
                msg.innerHTML = "TIE!";
        }
        if (gameoverall(board) == true || emptycells(board).length == 0) 
	{
                button.value = "Restart_Game";
                button.disabled = false;
        }

}

/* The below function is for restarting the game */
/* --------------------------------------------- */
function restartButton(button) 
{
        if (button.value == "Start Computer") 
	{
                AITurn();
                button.disabled = true;
        }
        else if (button.value == "Restart_Game") 
	{
                var htmlBoard;
                var msg;
                for (var x=0;x<3;x++) 
		{
                        for (var y=0;y<3;y++) 
			{
                                board[x][y] = 0;
                                htmlBoard = document.getElementById(String(x) + String(y));
                                htmlBoard.style.color = "#444";
                                htmlBoard.innerHTML = "";
                        }
                }
                button.value ="Start Computer";
                msg = document.getElementById("result");
                msg.innerHTML = "";
        }
}
